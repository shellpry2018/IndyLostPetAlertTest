Use this child theme to modify the parent theme to fit your needs. Make sure you DON'T remove the parent theme from your themes folder.

********************************************************************************
Read more about child themes here: http://codex.wordpress.org/Child_Themes
********************************************************************************